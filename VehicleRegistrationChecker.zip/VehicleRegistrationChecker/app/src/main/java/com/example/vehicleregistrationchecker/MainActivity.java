package com.example.vehicleregistrationchecker;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;

import java.text.DateFormat;
import java.util.Calendar;
import java.util.Date;

public class MainActivity extends AppCompatActivity {

    EditText etPlateNumber;
    TextView tvResult;
    TextView tvDate, tvMonth;
    Button btnCheck, btnClose;

    private double fine;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        etPlateNumber = findViewById(R.id.etPlateNumber);
        tvResult = findViewById(R.id.tvResult);
        btnCheck = findViewById(R.id.btnCheck);
        btnClose = findViewById(R.id.btnClose);
        tvDate = findViewById(R.id.tvDate);
        tvMonth = findViewById(R.id.tvMonth);

        Date currentTime = Calendar.getInstance().getTime();
        String formattedDate = DateFormat.getDateInstance(DateFormat.FULL).format(currentTime);

        tvDate.setText(formattedDate);

        String[] splitDate = formattedDate.split(",");


        btnCheck.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {



                String splitMonth = splitDate[1];
                String[] curr = splitDate[1].split(" ");

                String curYear = splitDate[2];
                String curMonth = curr[1];
                String curDay = curr[2];

                tvMonth.setText(curDay);

                String plate = etPlateNumber.getText().toString();
                String[] splitPlate = plate.split(" ");
                if(splitPlate[1].length() == 4) {
                    String[] pn = plate.split("");
                    double eight = Double.parseDouble(pn[7]);
                    double seven = Double.parseDouble(pn[6]);

                    double prsDay = Double.parseDouble(curDay);

                    if(seven >= 1 && seven <= 3){
                        if(prsDay > 7 ){
                            fine =+ 1500;
                        }
                    }

                    tvResult.setText(""+ fine);
                } else {
                    tvResult.setText("error");
                }


            }
        });

        btnClose.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                finish();
                System.exit(0);
            }
        });

    }

}